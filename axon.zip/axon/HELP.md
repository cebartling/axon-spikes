# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Spring Integration](https://docs.spring.io/spring-boot/docs/2.4.5/reference/htmlsingle/#boot-features-integration)
* [Spring for Apache Kafka](https://docs.spring.io/spring-boot/docs/2.4.5/reference/htmlsingle/#boot-features-kafka)
* [Kafka Clients](https://kafka.apache.org)
* [Spring Security](https://docs.spring.io/spring-boot/docs/2.4.5/reference/htmlsingle/#boot-features-security)
* [Spring Boot Actuator](https://docs.spring.io/spring-boot/docs/2.4.5/reference/htmlsingle/#production-ready)

### Guides
The following guides illustrate how to use some features concretely:

* [Integrating Data](https://spring.io/guides/gs/integration/)
* [Securing a Web Application](https://spring.io/guides/gs/securing-web/)
* [Spring Boot and OAuth2](https://spring.io/guides/tutorials/spring-boot-oauth2/)
* [Authenticating a User with LDAP](https://spring.io/guides/gs/authenticating-ldap/)
* [Building a RESTful Web Service with Spring Boot Actuator](https://spring.io/guides/gs/actuator-service/)

### Additional Links
These additional references should also help you:

* [The Axon Framework open-source code repository on GitHub](https://github.com/AxonFramework)
* [The reference guide on how to use Axon](https://docs.axoniq.io/reference-guide/)
* [A full getting started tutorial for Axon in small simple steps (YouTube).](https://www.youtube.com/watch?v=tqn9p8Duy54&list=PL4O1nDpoa5KQkkApGXjKi3rzUW3II5pjm)
* [The reference guide section on how to use Axon Test module](https://docs.axoniq.io/reference-guide/axon-framework/testing)
* [The reference guide section on how to use Axon Micrometer module](https://docs.axoniq.io/reference-guide/axon-framework/monitoring-and-metrics#micrometer)
* [The Axon Kotlin extension open-source code repository on GitHub](https://github.com/AxonFramework/extension-kotlin)
* [The reference guide section on how to use Axon Kotin extension](htps://docs.axoniq.io/reference-guide/extensions/kotlin)
* [The Axon Reactor extension open-source code repository for GitHub](https://github.com/AxonFramework/extension-reactor)
* [The reference guide section on how to use Axon Reactor extension](https://docs.axoniq.io/reference-guide/extensions/reactor)
* [The Axon Tracing extension open-source code repository on GitHub](https://github.com/AxonFramework/extension-tracing)
* [The reference guide section on how to use Axon Tracing extension](https://docs.axoniq.io/reference-guide/extensions/tracing)
* [The Axon Kafka extension open-source code repository on GitHub](https://github.com/AxonFramework/extension-kafka)
* [The reference guide section on how to use Axon Kafka extension](https://docs.axoniq.io/reference-guide/extensions/kafka)
* [The Axon Mongo extension open-source code repository on GitHub](https://github.com/AxonFramework/extension-mongo)
* [The reference guide section on how to use Axon Mongo extension](https://docs.axoniq.io/reference-guide/extensions/mongo)

